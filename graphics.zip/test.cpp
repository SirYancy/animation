  1  #define VERTEX_SHADER "draw_sphere.vert"
  2  #define FRAGMENT_SHADER "draw_sphere.frag"
  3  
  4  #define GL3_PROTOTYPES
  5  #include <GL3/gl3.h>
  6  #define __gl_h_
  7  
  8  #include <cstdlib>
  9  #include <string>
 10  #include <fstream>
 11  #include <iostream>
 12  #include <glm/glm.hpp>
 13  #include <GL/freeglut.h>
 14  #include "colladainterface.h"
 15  
 16  struct LightParameters {
 17    glm::vec4 diffuse_intensity;
 18    glm::vec4 ambient_intensity;
 19    glm::vec4 light_direction;
 20  };
 21  
 22  std::vector<ColGeom> geom_vec;    // Vector containing COLLADA meshes
 23  int num_objects;                  // Number of meshes in the vector
 24  GLuint *vaos, *vbos;              // OpenGL vertex objects
 25  GLuint ubo;                       // OpenGL uniform buffer object
 26  
 27  // Read a character buffer from a file
 28  std::string read_file(const char* filename) {
 29  
 30    // Open the file
 31    std::ifstream ifs(filename, std::ifstream::in);
 32    if(!ifs.good()) {
 33      std::cerr << "Couldn't find the shader file " << filename << std::endl;
 34      exit(1);
 35    }
 36    
 37    // Read file text into string and close stream
 38    std::string str((std::istreambuf_iterator<char>(ifs)), 
 39                     std::istreambuf_iterator<char>());
 40    ifs.close();
 41    return str;
 42  }
 43  
 44  // Compile the shader
 45  void compile_shader(GLint shader) {
 46  
 47    GLint success;
 48    GLsizei log_size;
 49    char *log;
 50  
 51    glCompileShader(shader);
 52    glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
 53    if (!success) {
 54      glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &log_size);
 55      log = new char[log_size+1];
 56      log[log_size] = '\0';
 57      glGetShaderInfoLog(shader, log_size+1, NULL, log);
 58      std::cout << log;
 59      delete(log);
 60      exit(1);
 61    }
 62  }
 63  
 64  // Create, compile, and deploy shaders
 65  GLuint init_shaders(void) {
 66  
 67    GLuint vs, fs, prog;
 68    std::string vs_source, fs_source;
 69    const char *vs_chars, *fs_chars;
 70    GLint vs_length, fs_length;
 71  
 72    // Create shader descriptors
 73    vs = glCreateShader(GL_VERTEX_SHADER);
 74    fs = glCreateShader(GL_FRAGMENT_SHADER);   
 75  
 76    // Read shader text from files
 77    vs_source = read_file(VERTEX_SHADER);
 78    fs_source = read_file(FRAGMENT_SHADER);
 79  
 80    // Set shader source code
 81    vs_chars = vs_source.c_str();
 82    fs_chars = fs_source.c_str();
 83    vs_length = (GLint)vs_source.length();
 84    fs_length = (GLint)fs_source.length();
 85    glShaderSource(vs, 1, &vs_chars, &vs_length);
 86    glShaderSource(fs, 1, &fs_chars, &fs_length);
 87  
 88    // Compile shaders and chreate program
 89    compile_shader(vs);
 90    compile_shader(fs);
 91    prog = glCreateProgram();
 92  
 93    // Bind attributes
 94    glBindAttribLocation(prog, 0, "in_coords");
 95    glBindAttribLocation(prog, 1, "in_normals");
 96  
 97    // Attach shaders
 98    glAttachShader(prog, vs);
 99    glAttachShader(prog, fs);
100  
101    glLinkProgram(prog);
102    glUseProgram(prog);
103  
104    return prog;
105  }
106  
107  // Create and initialize vertex array objects (VAOs)
108  // and vertex buffer objects (VBOs)
109  void init_buffers(GLuint program) {
110    
111    int loc;
112  
113    // Create a VAO for each geometry
114    vaos = new GLuint[num_objects];
115    glGenVertexArrays(num_objects, vaos);
116  
117    // Create a VBO for each geometry
118    vbos = new GLuint[2 * num_objects];
119    glGenBuffers(2 * num_objects, vbos);
120  
121    // Configure VBOs to hold positions and normals for each geometry
122    for(int i=0; i<num_objects; i++) {
123  
124      glBindVertexArray(vaos[i]);
125  
126      // Set vertex coordinate data
127      glBindBuffer(GL_ARRAY_BUFFER, vbos[2*i]);
128      glBufferData(GL_ARRAY_BUFFER, geom_vec[i].map["POSITION"].size, 
129                   geom_vec[i].map["POSITION"].data, GL_STATIC_DRAW);
130      loc = glGetAttribLocation(program, "in_coords");
131      glVertexAttribPointer(loc, geom_vec[i].map["POSITION"].stride, 
132                            geom_vec[i].map["POSITION"].type, GL_FALSE, 0, 0);
133      glEnableVertexAttribArray(0);
134  
135      // Set normal vector data
136      glBindBuffer(GL_ARRAY_BUFFER, vbos[2*i+1]);
137      glBufferData(GL_ARRAY_BUFFER, geom_vec[i].map["NORMAL"].size, 
138                   geom_vec[i].map["NORMAL"].data, GL_STATIC_DRAW);
139      loc = glGetAttribLocation(program, "in_normals");
140      glVertexAttribPointer(loc, geom_vec[i].map["NORMAL"].stride, 
141                            geom_vec[i].map["NORMAL"].type, GL_FALSE, 0, 0);
142      glEnableVertexAttribArray(1);
143    }
144  
145    glBindBuffer(GL_ARRAY_BUFFER, 0);
146    glBindVertexArray(0);
147  }
148  
149  // Initialize uniform data
150  void init_uniforms(GLuint program) {
151  
152    GLuint program_index, ubo_index;
153    struct LightParameters params;
154  
155    // Specify the rotation matrix
156    glm::vec4 diff_color = glm::vec4(0.3f, 0.3f, 1.0f, 1.0f);
157    GLint location = glGetUniformLocation(program, "diffuse_color");
158    glUniform4fv(location, 1, &(diff_color[0])); 
159  
160    // Initialize UBO data
161    params.diffuse_intensity = glm::vec4(0.5f, 0.5f, 0.5f, 1.0f);
162    params.ambient_intensity = glm::vec4(0.3f, 0.3f, 0.3f, 1.0f);
163    params.light_direction = glm::vec4(-1.0f, -1.0f, 0.25f, 1.0f);
164  
165    // Set the uniform buffer object
166    glUseProgram(program);
167    glGenBuffers(1, &ubo);
168    glBindBuffer(GL_UNIFORM_BUFFER, ubo);
169    glBufferData(GL_UNIFORM_BUFFER, 3*sizeof(glm::vec4), &params, GL_STREAM_DRAW);
170    glBindBuffer(GL_UNIFORM_BUFFER, 0);
171    glUseProgram(program);
172  
173    // Match the UBO to the uniform block
174    glUseProgram(program);
175    ubo_index = 0;
176    program_index = glGetUniformBlockIndex(program, "LightParameters");
177    glUniformBlockBinding(program, program_index, ubo_index);
178    glBindBufferRange(GL_UNIFORM_BUFFER, ubo_index, ubo, 0, 3*sizeof(glm::vec4));
179    glUseProgram(program);
180  }
181  
182  // Initialize the rendering objects
183  void init(int argc, char* argv[]) {
184  
185    // Initialize the main window
186    glutInit(&argc, argv);
187    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
188    glutInitWindowSize(300, 300);
189    glutCreateWindow("Draw Sphere");
190    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
191  
192    // Configure culling
193    glEnable(GL_CULL_FACE);
194    glCullFace(GL_BACK);
195    glFrontFace(GL_CW);
196  
197    // Enable depth testing
198    glEnable(GL_DEPTH_TEST);
199    glDepthMask(GL_TRUE);
200    glDepthFunc(GL_LEQUAL);
201    glDepthRange(0.0f, 1.0f);
202  
203    // Initialize shaders and buffers
204    GLuint program = init_shaders();
205    init_buffers(program);
206    init_uniforms(program);
207  }
208  
209  // Respond to paint events
210  void display(void) {
211    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
212  
213    // Draw elements of each mesh in the vector
214    for(int i=0; i<num_objects; i++) {
215      glBindVertexArray(vaos[i]);
216      glDrawElements(geom_vec[i].primitive, geom_vec[i].index_count, 
217                     GL_UNSIGNED_SHORT, geom_vec[i].indices);
218    }
219  
220    glBindVertexArray(0);
221    glutSwapBuffers();
222  }
223  
224  // Respond to reshape events
225  void reshape(int w, int h) {
226     glViewport(0, 0, (GLsizei)w, (GLsizei)h);
227  }
228  
229  // Deallocate memory
230  void deallocate() {
231  
232    // Deallocate mesh data
233    ColladaInterface::freeGeometries(&geom_vec);
234  
235    // Deallocate OpenGL objects
236    glDeleteBuffers(num_objects, vbos);
237    glDeleteBuffers(2 * num_objects, vaos);
238    glDeleteBuffers(1, &ubo);
239    delete(vbos);
240    delete(vaos);
241  }
242  
243  int main(int argc, char* argv[]) {
244  
245    // Initialize COLLADA geometries
246    ColladaInterface::readGeometries(&geom_vec, "sphere.dae");
247    num_objects = (int) geom_vec.size();
248  
249    // Start GL processing
250    init(argc, argv);
251  
252    // Set callback functions
253    glutDisplayFunc(display);
254    glutReshapeFunc(reshape);   
255  
256    // Configure deallocation callback
257    atexit(deallocate);
258  
259    // Start processing loop
260    glutMainLoop();
261  
262    return 0;
263  }
