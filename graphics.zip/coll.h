  1  #ifndef COLLADAINTERFACE_H
  2  #define COLLADAINTERFACE_H
  3  
  4  #include <iostream>
  5  #include <vector>
  6  #include <map>
  7  #include <sstream>
  8  #include <iterator>
  9  
 10  #include "GL3/gl3.h"
 11  #include "tinyxml/tinyxml.h"
 12  
 13  struct SourceData {
 14    GLenum type;
 15    unsigned int size;
 16    unsigned int stride;
 17    void* data;
 18  };
 19  
 20  typedef std::map<std::string, SourceData> SourceMap;
 21  
 22  struct ColGeom {
 23    std::string name;
 24    SourceMap map;
 25    GLenum primitive;
 26    int index_count;
 27    unsigned short* indices;
 28  };
 29  
 30  SourceData readSource(TiXmlElement*);
 31  
 32  class ColladaInterface {
 33  
 34  public:
 35    ColladaInterface() {};
 36    static void readGeometries(std::vector<ColGeom>*, const char*);
 37    static void freeGeometries(std::vector<ColGeom>*);
 38  };
 39  
 40  #endif
